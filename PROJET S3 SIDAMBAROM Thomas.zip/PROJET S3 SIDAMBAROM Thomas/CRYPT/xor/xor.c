#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wchar.h>


void chiffrage_xor(char * filename_text_a_crypte, char * clef , char * filename_texte_chiffre);


// MAIN QUI PERMET DE LANCER LE PROGRAMME SANS "dh_crypt.c" (VOIR 2.2.2 CAHIER DES CHARGES)

/*int main(int argc, char *argv[])
{
    

    if (argc != 3 )
    {
        printf("Erreur usage : ./xor.exe texte_a_crypte text_chiffre clef");
        return 1;
    }

    if (argv[1] == NULL)
    {
        printf("Erreur : Le fichier n'existe pas");
        return 2;
    }

    chiffrage_xor(argv[1],argv[3],argv[2]);
    return 0;

}*/



   
void chiffrage_xor(char * filename_text_a_crypte, char * clef , char * filename_texte_chiffre)

{   
    /// \brief effectue le chiffrage xor sur text_a_crypte, et le stock dans le text_chiffre
    /// \brief c'est un test statistique. Il est plus rapide que le précédent.
    /// \param[in] filename_text_a_crypte : fichier avec le message a crypte
    /// \param[in] filename_text_chiffre : fichier ou met le message chiffre

    FILE * texte_a_crypte = fopen(filename_text_a_crypte,"rb"); //on ouvre "texte_a_crypte" en lecture
    FILE * texte_chiffre = fopen(filename_texte_chiffre,"wb"); // on ouvre "texte_chiffre" en ecriture

    int compteur = 0;
    int buf; 
    
    if (texte_a_crypte == NULL) //on vérifie que "texte_a_crypte" existe bien
        {
            printf ("\nOuverture du fichier texte_a_crypte impossible ! \n");
            exit (EXIT_FAILURE);
        }   

    while ((buf = fgetc(texte_a_crypte)) != EOF)
    
        {
            printf("\nbuf = %d",buf);
            buf ^= clef[compteur]; //on xor chaque élément avec la clef
            printf("\nclef[compteur] = %d", clef[compteur]);
            printf("\nbuf_res = %d",buf);

            fprintf(texte_chiffre,"%c",buf); //et on stock chaque caractère chiffré dans "texte_chiffre"
            // printf("\nstrlen(clef) = %d",strlen(clef));
            if (compteur != strlen(clef)-1) 
                compteur+=1;
            else 
                compteur = 0 ;
            printf("\n");
        }
    fclose(texte_a_crypte);
    fclose(texte_chiffre);
    
}
