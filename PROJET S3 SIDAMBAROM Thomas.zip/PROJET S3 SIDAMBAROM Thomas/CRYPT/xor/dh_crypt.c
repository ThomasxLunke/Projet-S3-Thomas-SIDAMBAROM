#include "xor.c"
#include <unistd.h>
#include <string.h>

int main(int argc, char *argv[])
{
    char optstring[] = "hi:m:k:o:"; //indication sur les options possibles
    int c, taille_key, xor_int = 0 , cbc_int = 0 ;
    char * filename_texte_a_crypte = NULL, * filename_texte_chiffre = NULL, * key = NULL ;
    char xor[] = "xor", cbc[] = "cbc-crypt";
    int compteur = 0, k=0, i=0, m=0 , h=0 , o=0 ;
    for (int j = 0; j < argc; j++)
            {
                if (strcmp("-k",argv[j]) == 0)  //verifie si k existe
                    k = 1;
                if (strcmp("-i",argv[j]) == 0)  //verifie si i existe
                    i = 1;
                if (strcmp("-m",argv[j]) == 0)  //verifie si m existe
                    m = 1;
                if (strcmp("-o",argv[j]) == 0)  //verifie si o existe
                    o = 1;
                if (strcmp("-h",argv[j]) == 0)  //verifie si h existe
                    h = 1;
            }

    
    while ((c = getopt (argc,argv,optstring)) != EOF) //boucle jusqu'à la fin de la lecture des options
        {
            if (h == 1) //lance l'option -h et arrete le programme
                {
                    printf("\n \n ##################################################   HELP  ####################################################### \n \n");
                    printf ("\n./dh_crypt.exe -i fichier_a_decrypter.txt -o texte_chiffre -k clef -m xor --> Pour décrypter le fichier_a_decrypter");
                    printf ("\n./dh_crypt.exe -h--> Pour lancer toute cette aide");
                    return 1 ;
                }

            else 
                {
                    if (argc < 9) // verifie si il ya au moins 9 arguments
                        {   
                            printf("\nUsage erreur : ./dh_crack.exe -i fichier_a_decrypter -m 'xor' ou 'cbc-crypt' -k clef");
                            return 2;
                        }

                    if (k==1 && m==1 && i==1 && o==1) //vérifie si -k, -m, -i et -o sont présents dans l'appel au programme
                        {
                            if ((char) c == 'k') //detecte l'option k
                                {   
                                    key = optarg; //stock la valeur juste après l'option -k dans key
                                    if (key == NULL) //vérifie si il ya bien un optarg apres -k
                                        {   
                                            printf("\nErreur usage : Clé non disponible");
                                            return 3; 
                                        }
                                }
                            
                            if ((char) c == 'i') //detecte l'option i
                                {
                                    filename_texte_a_crypte = optarg; // "filename_texte_a_crypte" prend la valeur de optarg qui contien l'élément écrit après l'option i
                                    if (filename_texte_a_crypte == NULL) //verfie l'existence de "filename_texte_a_crypte"
                                        { 
                                            printf("\nEreur : Fichier introuvable");
                                            return 5;
                                        }  
                                }
                            if ((char) c == 'o') //detecte l'option o
                                    filename_texte_chiffre = optarg; 
                            
                            if ((char) c == 'm') //detecte l'option m
                                {   
                                    if (strcmp(optarg,xor) == 0) //si optarg et la chaine xor sont les même alors ...
                                        xor_int = 1; // ... xor_int recoit 1 ("xor_int" est un indicateur)
                                    if (strcmp(optarg,cbc) == 0) //si optarg et la chaine cbc sont les même alors ...
                                        cbc_int = 1; // ... cbc_int recoit 1 ("cbc_int" est un indicateur)
                                }
                    
                        }
                    else 
                        {
                            printf("\nErreur usage : ./dh_crack.exe -i fichier_a_decrypter -m 'xor' ou 'cbc-crypt' -k clef");
                            return 6;
                        }
                }
        }
                
    if (xor_int == 1) //si xor_int==1 alors on lance le chiffrage xor
        {
            chiffrage_xor(filename_texte_a_crypte, key , filename_texte_chiffre);
            return 0;
            
        }
    if (cbc_int == 1)//si cbc_int==1 alors on lance le chiffrage cbc
        {
            printf("\nFonction non implémenté");
            return 7;
        }

    return 8;



}
