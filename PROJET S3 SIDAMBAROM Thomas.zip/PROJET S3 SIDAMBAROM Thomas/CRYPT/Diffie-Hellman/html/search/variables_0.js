var searchData=
[
  ['dim_65',['dim',['../structt__words__lst.html#a70b5e28b5bc3d1b63a7435c5fe50b837',1,'t_words_lst']]]
];
