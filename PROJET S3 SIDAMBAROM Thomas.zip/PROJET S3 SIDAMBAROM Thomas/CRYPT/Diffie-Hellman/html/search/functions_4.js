var searchData=
[
  ['puissance_5fmod_5fn_58',['puissance_mod_n',['../dh__prime_8c.html#aa4b5ea98d589c0df414bdb825606c6ff',1,'puissance_mod_n(long a, long e, long n):&#160;dh_prime.c'],['../dh__prime_8h.html#aa4b5ea98d589c0df414bdb825606c6ff',1,'puissance_mod_n(long a, long e, long n):&#160;dh_prime.c']]]
];
