var searchData=
[
  ['patate_2etxt_50',['patate.txt',['../patate_8txt.html',1,'']]]
];
