var searchData=
[
  ['nb_5fdigit_5fbase10_26',['nb_digit_base10',['../dh__prime_8c.html#af52f9865b6bb877af4608e29d4f42e05',1,'nb_digit_base10(long n):&#160;dh_prime.c'],['../dh__prime_8h.html#af52f9865b6bb877af4608e29d4f42e05',1,'nb_digit_base10(long n):&#160;dh_prime.c']]]
];
