var searchData=
[
  ['seek_5fgenerator_33',['seek_generator',['../dh__prime_8c.html#a52d24f65da0f678f4e6aef536f7eab08',1,'seek_generator(long start, long p):&#160;dh_prime.c'],['../dh__prime_8h.html#a52d24f65da0f678f4e6aef536f7eab08',1,'seek_generator(long start, long p):&#160;dh_prime.c']]]
];
