var searchData=
[
  ['words_5ftab_39',['words_tab',['../structt__words__lst.html#ac84451cb5cca2b16b26fd96da2a14302',1,'t_words_lst']]]
];
