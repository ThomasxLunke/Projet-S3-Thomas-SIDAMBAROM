var searchData=
[
  ['longmax_77',['LONGMAX',['../dh_8h.html#aa464414e7d70568ff0949f9444450b6c',1,'dh.h']]]
];
