var searchData=
[
  ['xchange_5fshared_5fkey_40',['xchange_shared_key',['../dh__prime_8c.html#a6bbcd4f3b3ff639abcb6c67574ff0ca4',1,'xchange_shared_key(long generateur, long premier):&#160;dh_prime.c'],['../dh__prime_8h.html#a6bbcd4f3b3ff639abcb6c67574ff0ca4',1,'xchange_shared_key(long generateur, long premier):&#160;dh_prime.c']]],
  ['xchange_5fshared_5fkey_5ffile_41',['xchange_shared_key_file',['../dh__prime_8c.html#a113f381bffb3dcdcc3c4c55dc201ecca',1,'xchange_shared_key_file(long generateur, long premier, FILE *fichier_dh_genkey):&#160;dh_prime.c'],['../dh__prime_8h.html#a113f381bffb3dcdcc3c4c55dc201ecca',1,'xchange_shared_key_file(long generateur, long premier, FILE *fichier_dh_genkey):&#160;dh_prime.c']]]
];
