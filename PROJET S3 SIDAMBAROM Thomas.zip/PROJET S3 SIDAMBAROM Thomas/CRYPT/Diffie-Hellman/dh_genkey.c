#include "dh_prime.c"
#include <unistd.h>
#include <time.h>

/// \file dh_genkey.c
/// \author Thomas SIDAMBAROM
/// \date Janvier 2021
/// \brief Gestion des balise pour DH
int main(int argc, char *argv[])
{
    srand(time(NULL));
    char optstring[] = "ho:";
    int c;
    char *filename = NULL;

    if (argc == 1)
    {
        generate_shared_key(MIN_PRIME,MAX_PRIME,NULL);
    }

    while ((c = getopt (argc,argv,optstring)) != EOF)
    {
        if ((char) c == 'o')
            {
                filename = optarg;
                if(filename != NULL)
                    {
                        FILE * fichier_option_o = fopen(filename,"w");
                        generate_shared_key(MIN_PRIME,MAX_PRIME,fichier_option_o);
                        fclose(fichier_option_o);
                    }
            }
        if ((char) c == 'h')
            {
                printf("\n \n ##################################################   HELP  ####################################################### \n \n");
                printf ("\n./dh_genkey.exe --> Pour afficher à l'écran la méthode de Diffie-Hellman");
                printf ("\n./dh_genkey.exe -h --> Pour afficher l'aide");
                printf ("\n./dh_genkey.exe -o fichier.txt --> Pour écrire dans le 'fichier.txt' le détail de la méthode de Diffie-Hellman \n \n");
            }
    }
   
   // on affiche le premier argument.
   printf("%s\n",argv[optind]); 
   
  return 0;
  
}






