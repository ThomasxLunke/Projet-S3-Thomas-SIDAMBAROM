#define MAX_PRIME 4294967296/1000 // 2^32 = sqrt(2^64)
#define MIN_PRIME 100
#include <stdio.h>

long random_long(long min,long max);
int rabin (long a, long n) ;
long puissance_mod_n (long a, long e, long n);
//void xor(char *msg, char* key,int msg_length,char *crypted);
long generePremierRabin(long min,long max,int *cpt);
long seek_generator(long start,long p);
int nb_digit_base10(long n);
long generate_shared_key(long min,long max, FILE * fichier_dh_genkey);
long genPrimeSophieGermain(long min,long max,int *cpt);
long xchange_shared_key(long generateur, long premier);
long xchange_shared_key_file(long generateur, long premier, FILE * fichier_dh_genkey);  //fait la même chose que la fonction précédente mais copie le résultat dans un fichier plutot qu'à l'écran (change le stdout vers un fichier)
long int_pow(long a, long e);
