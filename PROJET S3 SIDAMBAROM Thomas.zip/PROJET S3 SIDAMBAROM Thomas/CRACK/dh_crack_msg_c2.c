#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <math.h>

#define MAX_TAILLE_KEY 100
#define TAILLE_ALPHABET 27 // +1 pour '\0'

/// \file dh_crack_msg_c2.c
/// \author Thomas SIDAMBAROM
/// \date Janvier 2021
/// \brief Projet : partie crack C2: ensemble de fonction pour la partie C2

struct score_clefs{int nb_clefs; float score_clefs_tri[1000]; int clefs_tri[1000];}; //structure qui stock le nombre de clé traité/trié,les clés triés, ainsi que leur score de fréquence associé.

void affichage_tab_float(float * tab_float, int taille_tab);
void affichaage_tab_int (int * tab, int taille_tab_key);
void remise_a_zero_de_tableau_int(int * nombre_de_lettre);
void remise_a_zero_de_tableau_float(float * freq);
void convertisseur_keyInt_en_keyChar(int key, char * tab_char);
void incrementation_nbr_lettre(int * nombre_de_lettre, char caractere);
int xor(int clefs_int, int taille_key, char * filename,char * tab_char,int * nombre_de_lettre);
void calcule_freq_theorique(float * freq, char * filename, int * nombre_de_lettre, int nbr_lettre );
float calcul_score_clef(float * freq, float * freq_theo);
void echanger_int(int *entier1, int*entier2);
void echanger_float(float * float1, float * float2);
void liste_score (struct score_clefs * SC,float score, int clef);
void lancement_C2(int * C1_tab_clefs,char * filename, int taille_tab);



//[123,254,321]

void lancement_C2(int * C1_tab_clefs,char * filename, int taille_tab)
{
    /// \brief permet de lancer l'enchainement de fonction de C2
    /// \param[in] filename : nom du fichier à décrypté
    /// \param[in] taille_tab : la taille du tableau contenant les clés venant de la partie C1
    /// \param[in] taille_tab : tableau de clé éligible venant de C1
    
    float freq_theo [] = {8.167,1.492,2.782,4.253,12.70,2.228,2.015,6.094,6.966,0.153,0.772,4.025,2.406,6.749,7.507,1.929,0.095,5.987,6.327,9.056,2.758,0.978,2.360,0.150,1.974,0.074}/*tableau de fréquence théorique de chaque lettres dans la langue anglaise */;
    float freq [] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0} /*tableau qui stockera les fréquences de chaque lettres pour chaque clé*/;
    int nombre_de_lettre [] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0} /*tableau qui stockera le nombre de lettres trouvées dans le fichier avec une clé donné*/, nbr_lettre ;
    float score_clef[10000];//clefs triés avec les score pour chaque clé
    
    float score;
    char tab_char[50]; //qui me servira de tableau relai pour transfomer les clé en int -> char *
    struct score_clefs SC;
    SC.nb_clefs = 0; //j'initialise le nombre de clef de de ma structure à 0

    //printf("\nC1_tab_clef[0] = %d",C1_tab_clefs[0]);
    //printf("\nC1_tab_clef[1] = %d",C1_tab_clefs[1]);
    //printf("\nC1_tab_clef[2] = %d",C1_tab_clefs[2]);

    for (int i = 0; i < taille_tab; i++)
    {
        nbr_lettre =  xor(C1_tab_clefs[i], taille_tab, filename,tab_char,nombre_de_lettre);//fonction qui permet de compter le nombre de lettre du texte et d'incrémenter le tableau "nombre_de_lettre"
        // printf("\n\ntaille_tab = %d", taille_tab);
        // printf("\n\nNbr de lettre = ");
        // affichaage_tab_int (nombre_de_lettre, 26); //affiche un tableau de int
        calcule_freq_theorique(freq,filename,nombre_de_lettre,nbr_lettre);// calcule la fréquence de chaque lettre par rapport au nombre de lettre présent dans le fichier
        // printf("\n\nC1_tab_clefs[%d] = %d  \n\n",i,C1_tab_clefs[i]) ; 
        // affichage_tab_float (freq, 26);
        
        score = calcul_score_clef(freq,freq_theo); //calcule le score de fréquence d'une clé 
        //printf("\nscore clef %d : %f", C1_tab_clefs[i],score);
    
        liste_score(&SC,score,C1_tab_clefs[i]); //permet l'ajout (dans la structure) des clés/scores de chaque clé, et le tri du moins bon score au meilleur score de chaque clé
        // printf("\n\nScore clef trie =  " );    
        // affichage_tab_float(SC.score_clefs_tri, SC.nb_clefs);
        // printf("\n\nClef trie =  " );    
        // affichaage_tab_int(SC.clefs_tri, SC.nb_clefs);

        remise_a_zero_de_tableau_float(freq); //permet de remettre toutes les fréquences à 0 en vue d'un test avec une nouvelle clé
        remise_a_zero_de_tableau_int(nombre_de_lettre); //permet de remettre toutes les lettres à 0 en vue d'un test avec une nouvelle clé

    }

    printf("\n\nClef trie de la moins bonne à la meilleur =  " );    
    affichaage_tab_int(SC.clefs_tri, SC.nb_clefs);
    printf("\n\nScore clef trie =  " );    
        affichage_tab_float(SC.score_clefs_tri, SC.nb_clefs);
    
}

void affichage_tab_float(float * tab_float, int taille_tab)
{   
    /// \brief permet d'afficher un tableau de float
    /// \param[in] taille_tab : taille du tableau de float à afficher
    /// \param[in] tab_float : tableau de float à afficher

    for (int i = 0; i < taille_tab ; i++)
        printf ("%f ",tab_float[i]);

}

void affichaage_tab_int (int * tab, int taille_tab_key)
{   
    /// \brief affiche un tableau de int
    /// \param[in] taille_tab_key : taille du tableau à afficher
    /// \param[in]  tab : tableau à afficher

    for (int i = 0; i < taille_tab_key ; i++)   
        printf ("%d ",tab[i]);
}

void remise_a_zero_de_tableau_int(int * nombre_de_lettre)
{   
    /// \brief permet de remettre a 0 un tableau de int
    /// \param[in] nombre_de_lettre : tableau de lettre a remettre à 0
    /// \param[out] nombre_de_lettre : renvoie le tableau remplie de 0

    for (int i =0 ; i< 26; i++)
        nombre_de_lettre[i] = 0;
}

void remise_a_zero_de_tableau_float(float * freq)
{   
    /// \brief permet de remettre à 0 un tableau de fréquence
    /// \param[in] nombre_de_lettre : tableau de fréquence a remettre à 0
    /// \param[out] nombre_de_lettre : renvoie le tableau remplie de 0

    for (int i =0 ; i< 26; i++)
        freq[i] = 0;
}

void convertisseur_keyInt_en_keyChar(int key, char * tab_char) 
{
    /// \brief convertis une clé initialement en int en char
    /// \param[in] key: clef en int
    /// \param[out] tab_char : tableau ou sera stocker la clé transformé en char

    sprintf(tab_char,"%d",key);  //Convertis la clé (int) en char
}

void incrementation_nbr_lettre(int * nombre_de_lettre, char caractere) //incrémente le tableau de "nombre_de_lettre" en fonction du caractère donné en entrée
{   
    /// \brief augmente la quantité de lettre dans le tableau "nombre_de_lettre" lié à chaque clé
    /// \param[in] min : nombre_de_lettre
    /// \param[out] caractere : le caractere a chercher
    
    switch (caractere)
    {
        case 'a' : nombre_de_lettre[0]++;break;  
        case 'b' : nombre_de_lettre[1]++;break;
        case 'c' : nombre_de_lettre[2]++;break;
        case 'd' : nombre_de_lettre[3]++;break;
        case 'e' : nombre_de_lettre[4]++;break;
        case 'f' : nombre_de_lettre[5]++;break;
        case 'g' : nombre_de_lettre[6]++;break;
        case 'h' : nombre_de_lettre[7]++;break;
        case 'i' : nombre_de_lettre[8]++;break;
        case 'j' : nombre_de_lettre[9]++;break;
        case 'k' : nombre_de_lettre[10]++;break;
        case 'l' : nombre_de_lettre[11]++;break;
        case 'm' : nombre_de_lettre[12]++;break;
        case 'n' : nombre_de_lettre[13]++;break;
        case 'o' : nombre_de_lettre[14]++;break;
        case 'p' : nombre_de_lettre[15]++;break;
        case 'q' : nombre_de_lettre[16]++;break;
        case 'r' : nombre_de_lettre[17]++;break;
        case 's' : nombre_de_lettre[18]++;break;
        case 't' : nombre_de_lettre[19]++;break;
        case 'u' : nombre_de_lettre[20]++;break;
        case 'v' : nombre_de_lettre[21]++;break;
        case 'w' : nombre_de_lettre[22]++;break;
        case 'x' : nombre_de_lettre[23]++;break;
        case 'y' : nombre_de_lettre[24]++;break;
        case 'z' : nombre_de_lettre[25]++;break;
        default : break;
    }
}

int xor(int clefs_int, int taille_key, char * filename,char * tab_char,int * nombre_de_lettre)
{
    /// \brief fonction qui permet de lancer "incrementation_nbr_lettre" sur tous les élément d'une clé et renvoie également le nombre de lettre d'un fichier texte
    /// \param[in] clefs_int : envoie la clé sous forme de int
    /// \param[in] taille_key: définis la taille des clés
    /// \param[in] filename : fichier a étudier pour trouver les clés adéquates
    /// \param[in] tab_char : tableau qui permet de stocker les clés sous forme de char
    /// \param[in] nombre_de_lettre : tableau mis a jour par "incrementation_nbr_lettres"
    /// \returns le nombre de lettre du texte

    convertisseur_keyInt_en_keyChar(clefs_int,tab_char);
    FILE * texte_a_decrypte = fopen(filename,"rb"); //ouvre le "texte_a_decrypte" en lecture
    int compteur = 0;
    int buf, nbr_lettre=0; 
    
    if (texte_a_decrypte == NULL) //on verifie que le fichier existe bien
        {
            printf ("Ouverture du fichier texte_a_crypte.txt impossible ! \n");
            exit (EXIT_FAILURE);
        }   

    while ((buf = fgetc(texte_a_decrypte)) != EOF) //on boucle tant que l'on est pas a la fin du fichier
    
        {   
            buf ^= tab_char[compteur]; //application de la méthode xor
            buf = tolower(buf); //on met le tout en miniscule pour la fonction "incrementation_nbr_lettre"
            incrementation_nbr_lettre(nombre_de_lettre,buf); //on augmente la quantité de lettres
            if (compteur != strlen(tab_char)-1) 
                compteur+=1;
            else 
                compteur = 0 ;
            printf("\n");
            if (buf != ' ' && isalpha(buf) != 0) //on compte le nombre de lettres (hors ponctuaction et espace)
                nbr_lettre++;
        }
    
    fclose(texte_a_decrypte);
    return nbr_lettre;
  
}


void calcule_freq_theorique(float * freq, char * filename, int * nombre_de_lettre, int nbr_lettre )
{   
    /// \brief calcule la fréquence theorique : (nombre_de_lettre[i] * 100) / nbr_lettre totale, et ceci pour chaque lettre
    /// \param[in] nombre_de_lettre : nombre de lettre pour chaque lettre d'une clé
    /// \param[in] nbr_lettre: nombre de lettre contenue dans filename
    /// \param[out] freq : score de fréquence lié a chaque lettre d'une clé
    /// \returns un nombre premier p min≤p≤max && p = 2*q+1 avec q premier

    //printf("\nnombre de lettre = %d\n",nbr_lettre);
    for (int i = 0; i < 26 ; i++) //26 pour la taille de l'alphabet
    {
        freq[i] = ((float) nombre_de_lettre[i] * 100) / nbr_lettre; //on met la fréquence en pourcentage par rapport au nombre de lettre du texte
    }

}

float calcul_score_clef(float * freq, float * freq_theo)
{   
    /// \brief calcule score de chaque clef : d(F req th, F req) = somme de 1 a 26 (freq_th[i] - freq[i]) ^ 2
    /// \param[in] freq : tableau de fréquence pour chaque lettre
    /// \param[in] freq_theo : tableau de fréquence théorique pour chaque lettre
    /// \returns du score finale de la clé
    float res = 0;
    for (int i = 0; i < 26; i++)
        res = res + ((freq_theo[i] - freq[i]) * (freq_theo[i] - freq[i])); //on calcule le score finale de la clé (avec la formule du cahier des charges)
    return res;
}


void liste_score (struct score_clefs * SC,float score, int clef) //on procède au tri de la moins bonne clé, à la meilleur
{   
    /// \brief tri la liste des scores du moins bon score au meilleur
    /// \param[in] score : score obtenu par une des clé
    /// \param[in] clef : la clé en int
    /// \param[out] score_clefs : score de toute les clés trié ainsi que les clé elle-mêmes trié de la moins bonne à la meilleur

    SC->clefs_tri[SC->nb_clefs] = clef;
    SC->score_clefs_tri[SC->nb_clefs] = fabs(score); //on met le score en valeur absolu pour faciliter le tri, ce qui nous interesse c'est la distance a 0 qui est faible si la clé est intéressante
    SC->nb_clefs++;

    int fin = SC->nb_clefs-1 , i=0 , compteur = 0, j=1;
        
    while (compteur != SC->nb_clefs-1)
    { 
        while (j <=fin)
        {
            if (SC->score_clefs_tri[i] < SC->score_clefs_tri[j])
            {
                echanger_int(&SC->clefs_tri[i],&SC->clefs_tri[j]);
                echanger_float(&SC->score_clefs_tri[i],&SC->score_clefs_tri[j]);
            }
            i++;
            j++;
        }
        fin--;
        compteur++;
        j=1;
        i=0;
    }
}

void echanger_int(int *entier1, int*entier2) //permet d'échanger deux int d'un tableau 
{   
    /// \brief permet d'échanger deux int par leur adresse
    /// \param[in] entier1 : entier à mettre à la place de entier2
    /// \param[in] entier2 : entier à mettre à la place de entier1
    
    int valeurtemporaire;
    valeurtemporaire= *entier1;
    *entier1 = *entier2;
    *entier2 = valeurtemporaire;
}

void echanger_float(float * float1, float * float2) //permet d'échanger deux float d'un tableau 
{
    /// \brief permet d'échanger deux float par leur adresse
    /// \param[in] entier1 : float à mettre à la place de float2
    /// \param[in] entier2 : float à mettre à la place de float1

    float valeurtemporaire;
    valeurtemporaire= * float1;
    *float1 = * float2;
    *float2 = valeurtemporaire;
}
    

