void affichage_tab_int (int * tab, int taille_tab_key)
{   
    /// \brief affiche un tableau de int
    /// \param[in] taille_tab_key : taille du tableau à afficher
    /// \param[in]  tab : tableau à afficher

    for (int i = 0; i < taille_tab_key ; i++)   
        printf ("%d ",tab[i]);
}