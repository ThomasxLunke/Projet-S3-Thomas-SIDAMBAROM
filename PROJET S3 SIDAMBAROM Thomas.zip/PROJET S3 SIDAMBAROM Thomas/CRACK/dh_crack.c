#include "dh_crack_c1.c"
#include "dh_crack_msg_c2.c"
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

int main(int argc, char *argv[])
{   
    char optstring[] = "hi:m:k:";   //indication des options possibles
    int c, taille_key, all_int = 0 , c1_int = 0 ;   
    char * filename = NULL ; //nom du fichier en entrée 
    char all[] = "all", c1[] = "c1";
        
    int compteur = 0, k=0, i=0, m=0 , h=0 ;
    for (int j = 0; j < argc; j++)
            {
                if (strcmp("-k",argv[j]) == 0)  //verifie si k existe
                    k = 1;
                if (strcmp("-i",argv[j]) == 0)  //verifie si i existe
                    i = 1;
                if (strcmp("-m",argv[j]) == 0)  //verifie si m existe
                    m = 1;
                if (strcmp("-h",argv[j]) == 0)  //verifie si h existe
                    h = 1;
            }
        
    while ((c = getopt (argc,argv,optstring)) != EOF) //boucle jusqu'à la fin de la lecture des options
        {
            if (h == 1) //lance l'option -h et arrete le programme
                {
                    printf("\n \n ##################################################   HELP  ####################################################### \n \n");
                    printf ("\n./dh_crack.exe -i fichier_a_decrypter.txt -m 'c1' ou 'all' -k taille_clef --> Pour décrypter le fichier_a_decrypter");
                    printf ("\n./dh_crack.exe -h--> Pour lancer toute cette aide");
                   
                    return 1 ;
                }

            else 
                {
                    if (argc < 7) // verifie si il ya au moins 7 arguments
                        {
                            printf("\nUsage erreur : ./dh_crack.exe -i fichier_a_decrypter -m 'c1' ou 'all' -k clef");
                            return 2;
                        }
                    
                    if (k==1 && m==1 && i==1) //vérifie si -k, -m, -i sont présents dans l'appel au programme
                        {
                            if ((char) c == 'k') //detecte l'option k
                                {   
                                    taille_key = atoi(optarg);  //transforme optarg en int
                                    if (isdigit(taille_key) == 0) //si c'est bien un chiffre alors ...
                                        taille_key = atoi(optarg); //..on stock la valeur dans taille_key
                                    else   
                                        printf("Erreur usage : l'option -k doit être suivi d'un chiffre (int)");   
                                }
                            
                            if ((char) c == 'i') //detecte l'option -i
                                {
                                    filename = optarg; //filename prend la valeur de l'objet placé après "-i"
                                    if (filename == NULL) //on verifie si le fichier existe
                                        { 
                                            printf("\nEreur : Fichier introuvable");
                                            return 4;
                                        }  
                                }

                            if ((char) c == 'm') //détecte l'option -m
                                {   
                                                    
                                    if (strcmp(optarg,all) == 0) //si ce qui suit "-m" est "all" alors ...
                                        all_int = 1;    //...on passe "all_int" à 1 ("all_int" sert d'indicateur)
                                    if (strcmp(optarg,c1) == 0) //si ce qui suit "-m" est "c1" alors ...
                                        c1_int = 1; //...on passe "c1_int" à 1 ("c1_int" sert d'indicateur)
                                }
                    
                        }
                    else 
                        {
                            printf("\nUsage erreur : ./dh_crack.exe -i fichier_a_decrypter -m 'c1' ou 'all' -k clef");
                            return 3;
                        }
                }
        }
                
    if (all_int == 1) //donc si l'utilisateur à fait le choix de lancer les fonction C1 puis C2 alors :
        {   
            int * C1_tab_clefs = lancement_c1(filename,taille_key); //on lance C1
            int taille_tab_key; 
            FILE * taille_tab_clef = fopen("taille_tab_clef.txt","r"); // on récupère la taille du tableau du résultat de C1 qui est stocker dans "taille_tab_clef.txt"
            fscanf(taille_tab_clef,"%d",&taille_tab_key); // on le stock dans "taille_tab_key"
            fclose(taille_tab_clef);
            printf("\nje suis tab_taille_key = %d",taille_tab_key);
            lancement_C2(C1_tab_clefs,filename,taille_tab_key); //puis on lance C2
        }
    if (c1_int == 1)
            lancement_c1(filename,taille_key); //on lance uniquement C1

    return 0;
            
}
    

