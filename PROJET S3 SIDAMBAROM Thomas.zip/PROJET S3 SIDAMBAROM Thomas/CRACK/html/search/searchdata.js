var indexSectionsWithContent =
{
  0: "1acdeilmnrstx",
  1: "s",
  2: "1dt",
  3: "aceilmnrstx",
  4: "cns",
  5: "mt"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Macros"
};

