var searchData=
[
  ['nb_5fclefs_68',['nb_clefs',['../structscore__clefs.html#a603f6050ecf172de0ee4828c1f3d1840',1,'score_clefs']]]
];
