var searchData=
[
  ['score_5fclefs_5ftri_69',['score_clefs_tri',['../structscore__clefs.html#a827fe7bcb49e51d421844446cc79aa6b',1,'score_clefs']]]
];
