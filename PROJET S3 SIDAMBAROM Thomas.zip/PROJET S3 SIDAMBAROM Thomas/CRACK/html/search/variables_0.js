var searchData=
[
  ['clefs_5ftri_67',['clefs_tri',['../structscore__clefs.html#ab63f92ab54710532ae8c3464e0c01ebd',1,'score_clefs']]]
];
