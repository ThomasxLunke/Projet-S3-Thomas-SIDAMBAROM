#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#define MAX_TAILLE_KEY 100

/// \file dh_crack_c1.c
/// \author Thomas SIDAMBAROM
/// \date Janvier 2021
/// \brief Projet : partie crack C1 : ensemble de fonction pour la partie C1

void suppression_element(int pos_i,int pos_j, char (*matrice) [10]);
void affichage_matrice (char (*matrice)[10], int taille_key);
int nombre_clef_matrice(char (*matrice) [10], int taille_key);
int nombre_element_ligne(char (*matrice) [10], int pos_i);
void init_tab (int * tab, int taille_tab_key);
void affichage_tab_int (int * tab, int taille_tab_key);
char caractere_de_clefs_possible(char caractere_a_tester,int position_caractere, char * filename, int taille_key);
void tri_caractere_de_clefs_possible(char (*matrice) [10], int taille_key, char * filename);
void creation_de_clefs(char (*matrice) [10], int * tab_clefs, int tab_taille_key, int taille_key);
int * lancement_c1(char * filename,int taille_key);


int * lancement_c1(char * filename,int taille_key)
{   /// \brief permet de lancer l'enchainement de fonction de C1
    /// \param[in] filename : nom du fichier à décrypté
    /// \param[in] taille_key : la taille de la clé de déchiffrage
    /// \returns l'ensemble des clés possible à essayer dans C2

    int i=0, j ,compteur =0, taille_tab_key;
    char matrice [taille_key] [10] , j_char; 
    
    while (i < taille_key)   //construit la matrice avec nombre de ligne = taille_key ... 
    {
        for ( j=0 ; j < 10 ; j++)  //... et nombre de colonnes = 10
            {   
                j_char = (char) j + 48;
                matrice [i] [j] = j_char ;  //on place des char de chiffre dans la matrice
                compteur ++;    
            }
        i++;
    }
    suppression_element(0,0,matrice); //car le premier 0 de la matrice doit être retirer d'après la consigne
    affichage_matrice(matrice,taille_key); //permet d'afficher une matrice
    printf ("\ntaille_ligne_3 = %d\n", nombre_element_ligne(matrice,2));
    tri_caractere_de_clefs_possible(matrice,taille_key,filename);   //fonction qui boucle sur tous les éléments d'une matrice et vérifie si les éléments donne un signe de ponctuation, une lettre, ou un chiffre
    printf("\n\n\n");
    taille_tab_key = nombre_clef_matrice(matrice,taille_key); //fonction qui permet de connaitre le nombre de clé qui sera générer (produit cartésien du nombre d'élément de chaque lignes)
    printf ("\ntaille_tab_key     = %d",taille_tab_key) ;
    int * tab_clefs = (int *) malloc (sizeof (int) * (taille_tab_key)); //crée un tableau de la taille "tab_tab_key" qui servira a stocker les clef candidate

    FILE * taille_tab_clef = fopen("taille_tab_clef.txt","w"); // stockage du nombre de clé_à tester dans le fichier "taille_tab_clef.txt"
    fprintf(taille_tab_clef,"%d",taille_tab_key);  
    fclose(taille_tab_clef);

    printf("\n");
   
    init_tab(tab_clefs, taille_tab_key); //crèe un tableau remplie de 0 de la taille "taille_tab_key"
     //affichage_tab_int(tab_clefs, taille_tab_key); //permet d'afficher un tableau de int
    creation_de_clefs(matrice, tab_clefs, taille_tab_key, taille_key); //fonction lancer par "tri_caractere_de_clefs_possible" et qui permet le tri

    affichage_matrice(matrice,taille_key);
    printf("\n");
    printf("\nVoici les clés candidate pour le C2 :  ");
    affichage_tab_int(tab_clefs, taille_tab_key);

    return tab_clefs;
}

void suppression_element(int pos_i,int pos_j, char (*matrice) [10])
{
    /// \brief permet de lancer l'enchainement de fonction de C1
    /// \param[in] pos_i : ligne du caractère a supprimer
    /// \param[in] pos_j : colonne du caractère a supprimer
    /// \param[in] matrice : la matrice a traiter

    matrice [pos_i] [pos_j] = ' '; //remplace un élément par un espace ' '
}

void affichage_matrice (char (*matrice)[10], int taille_key)
{   /// \brief permet d'afficher une matrice
    /// \param[in] matrice : matrice à afficher
    /// \param[in] taille_key : taille de la clé (pour connaitre le nombre de ligne de la matrice à affiché)
 
    for (int i = 0; i < taille_key ; i++)
        {
            printf("\n");
            for (int j=0 ; j <10 ; j++)
                {   
                    printf("%c ", matrice[i] [j]);
                }
        }
    printf("\n \n");
}

int nombre_clef_matrice(char (*matrice) [10], int taille_key)
{
    /// \brief determine le nombre de clé en fonction du nombre de caractère validé (multiplication du nombre d'élément de chaque ligne)
    /// \param[in] matrice : matrice que l'on recherce
    /// \param[in] taille_key : taille de la clé (pour connaitre le nombre de ligne de la matrice à affiché)
    /// \returns le nombre de clef

    int nombre_element = 0, nombre_clef = 1;
    for (int i=0 ; i < taille_key ; i++ )
    {
        for (int j=0 ; j < 10 ; j++)
        {
            if (matrice [i] [j] != ' ')
                nombre_element  ++;
        }
        if (nombre_element != 0)
            nombre_clef = nombre_clef * nombre_element;
        //printf("\nnombre_clef = %d",nombre_clef);
        nombre_element = 0;

    }
    return nombre_clef ;

}

int nombre_element_ligne(char (*matrice) [10], int pos_i) 
{
    /// \brief fonction qui permet de compter le nombre d'élément sur une ligne d'une matrice
    /// \param[in] matrice : matrice a traité
    /// \param[in] pos_i : la ligne de la matrice à compter
    /// \returns un nombre compris entre 0 et 10
    int nombre_element_ligne = 0;

    for (int j=0 ; j < 10 ; j++)
    {
        if (matrice [pos_i] [j] != ' ') //on ne compte pas les éléments espaces, qui sont assimilés a un élément supprimé
            nombre_element_ligne++ ;
    }
    return nombre_element_ligne ;

}

void init_tab (int * tab, int taille_tab_key)
{
    /// \brief permet de creer un tableau de int avec pour chaque valeur le chiffre 0 
    /// \param[in] taille_tab_key : la taille du tableau a initialiser
    /// \param[out] tab : le tableau créé
  
    for (int i = 0; i < taille_tab_key ; i++) //initialisation d'un tableau de taille "taille_tab_key" avec les valeurs 0 pour chaque cases du tableau
        tab[i] = 0;
}

void affichage_tab_int (int * tab, int taille_tab_key)
{   
    /// \brief affiche un tableau de int
    /// \param[in] taille_tab_key : taille du tableau à afficher
    /// \param[in]  tab : tableau à afficher

    for (int i = 0; i < taille_tab_key ; i++)   
        printf ("%d ",tab[i]);
}


char caractere_de_clefs_possible(char caractere_a_tester, int position_caractere, char * filename, int taille_key)
{
    /// \brief fonction qui permet de voir si un caractère est éligible pour devenir un caractère de clef
    /// \param[in] caractere_a_tester : le pontentiel future caractère de clef
    /// \param[in] position_caractere : la position du caractere dans la matrice (position qui correspond a la ligne ou le caractère se trouve)
    /// \param[in] taille_key : la taille de la clé
    /// \param[in] filename : fichier a décrypter avec les clés
    /// \returns soit un espace ' ' (supression de l'élément), soit le caractère inchangé si il passe tous les tests avec succès

    //printf("\ncaractere_a_tester = %d , position_caractere = %d",caractere_a_tester,position_caractere);
    FILE * fichier_a_decrypter = fopen(filename,"rb"); //on ouvre le fichier en lecture

    int fin = 0, buf, compteur = 1;
    if (fichier_a_decrypter == NULL) //on verifie si le fichier existe bien
    {
        printf("\nErreur : Le fichier n'existe pas ou n'est pas accessible");
        exit(EXIT_FAILURE);
    }

    while ((buf = fgetc(fichier_a_decrypter)) != EOF) //on boucle jusqu'à la fin du fichier
    {   
        
        if (compteur == position_caractere) //le compteur indique sur quel caractère du fichier nous sommes afin d'essayer chaque caractère de clé sur le bon élément. Car on sait que  : clef[0] sert a coder les caracteres 1, 4, ..., 1 + 3k,                              
        {   
                printf("\nbuf = %d",buf);
                buf ^= caractere_a_tester; //on xor, et on stock le résultat dans "buf"
                printf("    caractere_a_tester = %d",caractere_a_tester);
                printf("    buf_res = %d",buf);
                if (isalnum(buf) == 0 &&  ispunct(buf) == 0 && isspace(buf) == 0) //si le caractère n'est pas alphanumérique/ponctuation, on supprime le caractère de la clé en cours de test
                {
                   printf("\nCaractère incorrect.");
                    return ' ';
                }
                if (compteur == taille_key) //si le compteur arrive à la taille de la clé, on rénitialise le compteur à 1
                compteur = 1;
                else 
                compteur ++; //sinon on incrémente le compteur
        }
        else if (compteur == taille_key)
                compteur = 1;

        else if (compteur != position_caractere && compteur != taille_key)
            compteur ++;
    
    }

    fclose(fichier_a_decrypter);
    return caractere_a_tester;

}

void tri_caractere_de_clefs_possible(char (*matrice) [10], int taille_key, char * filename)
{
    /// \brief fonction qui permet de coordonnée l'utilisation de la fonction "caractere_de_clefs_possible". Elle applique les effets de cette dernière sur toute la matrice.
    /// \param[in] matrice : la matrice à étudier
    /// \param[in] taille_key : la taille de la clé
    /// \param[in] filename : permet de faire le read sur le filename
  
    for (int i = 0; i < taille_key ; i++)
    {
        for (int j = 0 ; j < 10 ; j++)
            {
                printf("\n\nmatrice [%d] [%d] = %c ",i,j,matrice[i][j]);
                matrice[i][j] = caractere_de_clefs_possible(matrice [i] [j], i+1, filename, taille_key); //on lance la fonction "caractere_de_clefs_possible" sur chaque élément de la matrice; afin de verifier, pour chaque caractère de la clé, si ces derniers sont correctes
            }
        printf("\n");
    }

}

void creation_de_clefs(char (*matrice) [10], int * tab_clefs, int tab_taille_key, int taille_key) //c'est ici que nous allons créé toute les combinaisons de clé possible
{   
    /// \brief crèe les clefs complètent a tester dans la partie C2
    /// \param[in] tab_taille_key : taille du tableau contenant les clef finales
    /// \param[in] taille_key : taille d'une clé type
    /// \param[out] tab_clefs : tableau contenant toute les combinaison de clés
  
    int nbr_element,nombre_elem_ligne = nombre_element_ligne(matrice, 0), compteur1=0, paquet = (tab_taille_key / nombre_elem_ligne) * nombre_elem_ligne, nb_paquet = 0, compteur_paquet=0, j,compteur_nb_elem_ligne; 

    for (int i = 0; i < taille_key; i++) //pour chaque ligne de la matrice de caractère de clés ...
    {
        
        //printf("\ntaille_key = %d",taille_key);
        if (((nombre_elem_ligne = nombre_element_ligne(matrice, i)) != 0)) //... si il ya au moins un élément sur la ligne étudié...
        {

            paquet = paquet / nombre_elem_ligne; //"paquet" défini par nombre de combien je vais inserer les éléments de chaque lignes dans le tab_clefs
            //printf("\n paquet = %d",paquet);
            //printf("\nnombre_elem_ligne = %d",nombre_elem_ligne);
           
            compteur1 = 0;
            compteur_nb_elem_ligne=0;
            compteur_paquet=0;
            j = 0;
            // printf("\ncompteur1 = %d",compteur1);
            // printf("\nj = %d",compteur1);
            // printf("\ncompteur_nb_elem_ligne = %d",compteur_nb_elem_ligne);
            
            while (j < tab_taille_key) //tant que l'on a pas remplie toute les cases du tab_clefs pour une ligne ...
                {
                    while (compteur_paquet < paquet) // ...tant qu'on a pas finis de mettre un paquet d'un caractère ... 
                    {   
                        if (matrice [i] [compteur_nb_elem_ligne] != ' ') //on verifie si l'élément n'a pas été supprimé
                        {
                            tab_clefs[compteur1] = (tab_clefs[compteur1] * 10) + ((int) matrice [i] [compteur_nb_elem_ligne] - 48); //on multiplie par 10 l'élément dans la case, et on y ajoute le caractère de la clé
                            //printf("\ntab_clefs[%d] = %d \n",compteur1, tab_clefs[compteur1]);
                            compteur_paquet++;
                            compteur1++;
                            j++;
                        }
                        else
                            compteur_paquet++;
                    }
                    compteur_nb_elem_ligne++;
                    if (compteur_nb_elem_ligne == 10 )
                        compteur_nb_elem_ligne = 0;
                    compteur_paquet = 0;
                   

                }
            
        }
        
    }
    
    

}